/* Адрес центрального сервера Raut. Генерируется scripts/build-installer.sh. */
window.RAUT_DEFAULT_SERVER = "";
