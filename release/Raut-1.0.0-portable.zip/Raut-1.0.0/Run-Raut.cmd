@echo off
rem Raut portable launcher (no installer, no registry, no WSH)
cd /d "%~dp0"
start "Raut Server" /MIN "bin\node.exe" "app\server\index.js" --client "app\client" --data "app\data" --host 0.0.0.0 --port 8787 --open
