/* Сгенерировано scripts/build-installer.sh */
window.RAUT_DEFAULT_SERVER = "";
window.RAUT_DISCOVERY_URL = 'https://api.github.com/repos/MatronixOwner/Raut/contents/SERVER_URL.txt?ref=arena/d55d4f5c-raut';
